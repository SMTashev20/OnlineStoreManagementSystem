﻿using OnlineStoreManagementSystem.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineManagementSystem.DAL.Entities
{
    public class PhysicalProduct : Product
    {
        public double Weight { get; set; }

        public override void DisplayDetails()
        {
            base.DisplayDetails();
            Console.WriteLine($"Weight: {Weight} kg");
        }
    }
}
