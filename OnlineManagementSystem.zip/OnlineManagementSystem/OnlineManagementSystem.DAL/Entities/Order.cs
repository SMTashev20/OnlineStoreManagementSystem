﻿using OnlineStoreManagementSystem.DAL.Entities;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineManagementSystem.DAL.Entities
{
    public class Order
    {
        public int Id { get; set; }
        public Customer Customer { get; set; } 
        public Product Product { get; set; }
        public int Quantity { get; set; } = 0;

        public decimal CalculateTotal()
        {
            decimal total = Product.Price * Quantity;
            return total;
        }
    }
}
