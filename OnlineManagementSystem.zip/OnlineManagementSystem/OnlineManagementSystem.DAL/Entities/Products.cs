﻿using System;

namespace OnlineStoreManagementSystem.DAL.Entities
{
    public abstract class Product
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public decimal Price { get; set; }
        public int Stock { get; set; }

        public event EventHandler<EventArgs>? OutOfStock;

        public virtual void DisplayDetails()
        {
            Console.WriteLine($"Product: {Name}, Price: ${Price}, Stock: {Stock}");
        }

        protected virtual void OnOutOfStock()
        {
            OutOfStock?.Invoke(this, EventArgs.Empty);
        }

        public virtual bool DeductStock(int quantity)
        {
            if (quantity <= Stock)
            {
                Stock -= quantity;
                if (Stock == 0)
                {
                    OnOutOfStock();
                }
                return true;
            }
            return false;
        }
    }
}