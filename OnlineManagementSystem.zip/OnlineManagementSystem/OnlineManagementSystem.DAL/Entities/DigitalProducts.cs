﻿using OnlineStoreManagementSystem.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineManagementSystem.DAL.Entities
{
    public class DigitalProduct : Product
    {
        public string DownloadLink { get; set; } = "";

        public override void DisplayDetails()
        {
            base.DisplayDetails();
            Console.WriteLine($"Download Link: {DownloadLink}");
        }
    }
}
