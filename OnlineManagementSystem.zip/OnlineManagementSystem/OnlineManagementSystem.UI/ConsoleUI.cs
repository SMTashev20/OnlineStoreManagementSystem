﻿using OnlineStoreManagementSystem.BLL.Services;
using OnlineStoreManagementSystem.DAL.Entities;
using OnlineStoreManagementSystem.BLL.Models.Discounts;
using OnlineStoreManagementSystem.BLL.Models.Payments;
using OnlineManagementSystem.DAL.Entities;

namespace OnlineStoreManagementSystem.PL
{
    public class ConsoleUI
    {
        private readonly IProductService _productService;
        private readonly ICustomerService _customerService;
        private readonly IOrderService _orderService;

        public ConsoleUI(IProductService productService, ICustomerService customerService, IOrderService orderService)
        {
            _productService = productService;
            _customerService = customerService;
            _orderService = orderService;
        }

        public void Run()
        {
            while (true)
            {
                Console.WriteLine("\n1. Add Product");
                Console.WriteLine("2. Add Customer");
                Console.WriteLine("3. Create Order");
                Console.WriteLine("4. Exit");
                Console.Write("Enter your choice: ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AddProduct();
                        break;
                    case "2":
                        AddCustomer();
                        break;
                    case "3":
                        CreateOrder();
                        break;
                    case "4":
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }

        private void AddProduct()
        {
            Console.WriteLine("\nAdding a new product:");
            Console.Write("Enter product name: ");
            string name = Console.ReadLine();

            Console.Write("Enter product price: ");
            if (!decimal.TryParse(Console.ReadLine(), out decimal price))
            {
                Console.WriteLine("Invalid price. Product not added.");
                return;
            }

            Console.Write("Enter initial stock: ");
            if (!int.TryParse(Console.ReadLine(), out int stock))
            {
                Console.WriteLine("Invalid stock. Product not added.");
                return;
            }

            Console.Write("Is this a physical product? (y/n): ");
            bool isPhysical = Console.ReadLine().ToLower() == "y";

            Product product;
            if (isPhysical)
            {
                Console.Write("Enter product weight (kg): ");
                if (!double.TryParse(Console.ReadLine(), out double weight))
                {
                    Console.WriteLine("Invalid weight. Product not added.");
                    return;
                }
                product = new PhysicalProduct { Name = name, Price = price, Stock = stock, Weight = weight };
            }
            else
            {
                Console.Write("Enter download link: ");
                string downloadLink = Console.ReadLine();
                product = new DigitalProduct { Name = name, Price = price, Stock = stock, DownloadLink = downloadLink };
            }

            _productService.AddProduct(product);
            Console.WriteLine("Product added successfully.");
        }

        private void AddCustomer()
        {
            Console.WriteLine("\nAdding a new customer:");
            Console.Write("Enter customer's first name: ");
            string firstName = Console.ReadLine();

            Console.Write("Enter customer's last name: ");
            string lastName = Console.ReadLine();

            Customer customer = new Customer { FirstName = firstName, LastName = lastName };
            _customerService.AddCustomer(customer);
            Console.WriteLine("Customer added successfully.");
        }

        private void CreateOrder()
        {
            Console.WriteLine("\nCreating a new order:");

            Console.Write("Enter customer ID: ");
            if (!int.TryParse(Console.ReadLine(), out int customerId))
            {
                Console.WriteLine("Invalid customer ID. Order not created.");
                return;
            }

            Customer customer = _customerService.GetCustomerById(customerId);
            if (customer == null)
            {
                Console.WriteLine("Customer not found. Order not created.");
                return;
            }

            Console.Write("Enter product ID: ");
            if (!int.TryParse(Console.ReadLine(), out int productId))
            {
                Console.WriteLine("Invalid product ID. Order not created.");
                return;
            }

            Product product = _productService.GetProductById(productId);
            if (product == null)
            {
                Console.WriteLine("Product not found. Order not created.");
                return;
            }

            Console.Write("Enter quantity: ");
            if (!int.TryParse(Console.ReadLine(), out int quantity) || quantity <= 0)
            {
                Console.WriteLine("Invalid quantity. Order not created.");
                return;
            }

            if (quantity > product.Stock)
            {
                Console.WriteLine("Insufficient stock. Order not created.");
                return;
            }

            Order order = new Order { Customer = customer, Product = product, Quantity = quantity };

            Console.Write("Apply discount? (y/n): ");
            if (Console.ReadLine().ToLower() == "y")
            {
                Console.Write("Enter discount type (1 for Fixed, 2 for Percentage): ");
                string discountType = Console.ReadLine();

                if (discountType == "1")
                {
                    Console.Write("Enter fixed discount amount: ");
                    if (decimal.TryParse(Console.ReadLine(), out decimal fixedAmount))
                    {
                        order.Discount = new FixedDiscount { DiscountAmount = fixedAmount };
                    }
                }
                else if (discountType == "2")
                {
                    Console.Write("Enter discount percentage: ");
                    if (decimal.TryParse(Console.ReadLine(), out decimal percentage))
                    {
                        order.Discount = new PercentageDiscount { DiscountPercentage = percentage };
                    }
                }
            }

            Console.Write("Enter payment method (1 for Credit Card, 2 for PayPal): ");
            string paymentMethod = Console.ReadLine();

            if (paymentMethod == "1")
            {
                Console.Write("Enter credit card number: ");
                string cardNumber = Console.ReadLine();
                Console.Write("Enter card holder name: ");
                string cardHolderName = Console.ReadLine();
                order.Payment = new CreditCardPayment { CardNumber = cardNumber, CardHolderName = cardHolderName };
            }
            else if (paymentMethod == "2")
            {
                Console.Write("Enter PayPal email: ");
                string email = Console.ReadLine();
                order.Payment = new PayPalPayment { Email = email };
            }
            else
            {
                Console.WriteLine("Invalid payment method. Order not created.");
                return;
            }

            if (order.ProcessOrder())
            {
                _orderService.AddOrder(order);
                Console.WriteLine($"Order created successfully. Total: ${order.CalculateTotal()}");
            }
            else
            {
                Console.WriteLine("Failed to process the order. Please try again.");
            }
        }
    }
}