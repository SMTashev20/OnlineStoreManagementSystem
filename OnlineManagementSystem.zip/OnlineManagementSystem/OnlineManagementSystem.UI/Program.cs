﻿using OnlineManagementSystem.DAL.Repositories;
using OnlineManagementSystem.BLL.Services;
using OnlineStoreManagementSystem.PL;

namespace OnlineStoreManagementSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialize repositories (you would typically use dependency injection here)
            IProductRepository productRepository = new ProductRepository();
            ICustomerRepository customerRepository = new CustomerRepository();
            IOrderRepository orderRepository = new OrderRepository();

            // Initialize services
            IProductService productService = new ProductService(productRepository);
            ICustomerService customerService = new CustomerService(customerRepository);
            IOrderService orderService = new OrderService(orderRepository, productService);

            // Create and run the UI
            ConsoleUI ui = new ConsoleUI(productService, customerService, orderService);
            ui.Run();
        }
    }
}