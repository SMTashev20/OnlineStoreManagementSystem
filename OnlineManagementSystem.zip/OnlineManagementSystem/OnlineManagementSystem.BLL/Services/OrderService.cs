﻿using OnlineManagementSystem.DAL.Entities;
using OnlineManagementSystem.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineManagementSystem.BLL.Services
{
    public interface IOrderService
    {
        Order GetOrderById(int id);
        void AddOrder(Order order);
        void UpdateOrder(Order order);
        void DeleteOrder(int id);
    }

    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _orderRepository;
        private readonly IProductService _productService;

        public OrderService(IOrderRepository orderRepository, IProductService productService)
        {
            _orderRepository = orderRepository;
            _productService = productService;
        }

        public Order GetOrderById(int id) => _orderRepository.GetById(id);
        public void AddOrder(Order order) => _orderRepository.Add(order);
        public void UpdateOrder(Order order) => _orderRepository.Update(order);
        public void DeleteOrder(int id) => _orderRepository.Delete(id);
    }
}
