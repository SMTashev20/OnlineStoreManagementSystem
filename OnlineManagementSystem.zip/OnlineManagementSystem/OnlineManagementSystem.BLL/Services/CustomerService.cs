﻿using OnlineManagementSystem.DAL.Entities;
using OnlineManagementSystem.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineManagementSystem.BLL.Services
{
    public interface ICustomerService
    {
        Customer GetCustomerById(int id);
        void AddCustomer(Customer customer);
        void UpdateCustomer(Customer customer);
        void DeleteCustomer(int id);
    }

    public class CustomerService : ICustomerService
    {
        private readonly ICustomerRepository _customerRepository;

        public CustomerService(ICustomerRepository customerRepository)
        {
            _customerRepository = customerRepository;
        }

        public Customer GetCustomerById(int id) => _customerRepository.GetById(id);
        public void AddCustomer(Customer customer) => _customerRepository.Add(customer);
        public void UpdateCustomer(Customer customer) => _customerRepository.Update(customer);
        public void DeleteCustomer(int id) => _customerRepository.Delete(id);
    }

}
