﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineManagementSystem.DAL.Entities;
using OnlineManagementSystem.DAL.Repositories;
using OnlineStoreManagementSystem.DAL.Entities;

namespace OnlineManagementSystem.BLL.Services
{
    public interface IProductService
    {
        Product GetProductById(int id);
        void AddProduct(Product product);
        void UpdateProduct(Product product);
        void DeleteProduct(int id);
    }

    public class ProductService : IProductService
    {
        private readonly IProductRepository _productRepository;

        public ProductService(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        public Product GetProductById(int id) => _productRepository.GetById(id);
        public void AddProduct(Product product) => _productRepository.Add(product);
        public void UpdateProduct(Product product) => _productRepository.Update(product);
        public void DeleteProduct(int id) => _productRepository.Delete(id);
    }


}
