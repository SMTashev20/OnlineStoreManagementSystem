﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineManagementSystem.BLL.Models.Discounts
{
    public class FixedDiscount : IDiscount
    {
        public decimal DiscountAmount { get; set; }

        public decimal ApplyDiscount(decimal originalPrice)
        {
            return Math.Max(originalPrice - DiscountAmount, 0);
        }
    }
}
