﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineManagementSystem.BLL.Models.Discounts
{
    public class PercentageDiscount : IDiscount
    {
        public decimal DiscountPercentage { get; set; }

        public decimal ApplyDiscount(decimal originalPrice)
        {
            return originalPrice * (1 - DiscountPercentage / 100);
        }
    }
}
